// React imports
import React, { useState } from 'react';
import axios from 'axios';

function App() {
  const [birthdate, setBirthdate] = useState('');
  const [horoscope, setHoroscope] = useState(null);
  const [talisman, setTalisman] = useState(null);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/horoscope', { birthdate });
      setHoroscope(response.data.horoscope);
      setTalisman(response.data.talisman);
      setError(null);
    } catch (err) {
      setError('Failed to fetch horoscope. Please try again.');
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-4">
      <h1 className="text-2xl font-bold mb-4">Daily Horoscope & Talisman</h1>
      <form onSubmit={handleSubmit} className="mb-6">
        <label className="block text-lg font-medium mb-2">Enter your birthdate:</label>
        <input
          type="date"
          value={birthdate}
          onChange={(e) => setBirthdate(e.target.value)}
          className="p-2 border rounded w-full mb-4"
        />
        <button type="submit" className="px-4 py-2 bg-blue-500 text-white rounded">Get Horoscope</button>
      </form>

      {error && <p className="text-red-500 mb-4">{error}</p>}

      {horoscope && (
        <div className="bg-white p-4 rounded shadow-md text-center">
          <h2 className="text-xl font-bold">Horoscope</h2>
          <p>{horoscope.description}</p>
        </div>
      )}

      {talisman && (
        <div className="mt-6">
          <h2 className="text-lg font-bold mb-2">Your Talisman</h2>
          <img src={`data:image/png;base64,${talisman}`} alt="Talisman" className="w-64 h-64 object-contain" />
        </div>
      )}
    </div>
  );
}

export default App;
