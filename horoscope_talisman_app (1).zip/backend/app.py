from flask import Flask, request, jsonify
from datetime import datetime
import random
from PIL import Image, ImageDraw, ImageFont
import io
import base64

app = Flask(__name__)

def generate_horoscope(birthdate):
    year = birthdate.year
    chinese_zodiac = ["Rat", "Ox", "Tiger", "Rabbit", "Dragon", "Snake", "Horse", "Goat", "Monkey", "Rooster", "Dog", "Pig"]
    element_cycle = ["Wood", "Fire", "Earth", "Metal", "Water"]
    zodiac_sign = chinese_zodiac[year % 12]
    element = element_cycle[(year - 4) % 10 // 2]

    luck = random.choice(["prosperity", "health", "love", "career success", "wisdom"])
    description = (
        f"You were born in the Year of the {zodiac_sign} ({element} Element). Today, focus on {luck} to "
        "enhance your fortune. Carry this talisman as a symbol of your strengthened luck."
    )

    return {"zodiac": zodiac_sign, "element": element, "luck": luck, "description": description}

def generate_talisman(horoscope):
    image = Image.new("RGB", (500, 500), color=(255, 255, 200))
    draw = ImageDraw.Draw(image)

    font = ImageFont.load_default()
    draw.text((20, 20), f"{horoscope['zodiac']} ({horoscope['element']})", fill=(0, 0, 0), font=font)
    draw.text((20, 60), f"Focus: {horoscope['luck']}", fill=(0, 0, 0), font=font)

    for _ in range(10):
        x1, y1 = random.randint(50, 450), random.randint(100, 450)
        x2, y2 = x1 + random.randint(20, 50), y1 + random.randint(20, 50)
        draw.ellipse([x1, y1, x2, y2], fill=(random.randint(100, 255), random.randint(100, 255), random.randint(100, 255)))

    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    buffer.seek(0)
    img_str = base64.b64encode(buffer.getvalue()).decode("utf-8")
    return img_str

@app.route("/horoscope", methods=["POST"])
def horoscope():
    try:
        data = request.json
        birthdate = datetime.strptime(data["birthdate"], "%Y-%m-%d")

        horoscope = generate_horoscope(birthdate)
        talisman_image = generate_talisman(horoscope)

        response = {
            "horoscope": horoscope,
            "talisman": talisman_image
        }
        return jsonify(response)

    except Exception as e:
        return jsonify({"error": str(e)}), 400

if __name__ == "__main__":
    app.run(debug=True)